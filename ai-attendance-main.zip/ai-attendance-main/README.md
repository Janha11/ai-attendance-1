# ai-attendance
AI-Powered Hourly Attendance Capturing System for college students
